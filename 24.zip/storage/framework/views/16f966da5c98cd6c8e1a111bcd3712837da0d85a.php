<tr>
    <td><?php echo e($product->id); ?></td>
    <td><?php echo e($product->barcode->code); ?></td>
    <td><?php echo e($product->description); ?></td>
    <td><?php echo e($quantity); ?></td>
    <td><?php echo e($product->cost->unit_price); ?></td>
    <td><?php echo e($product->cost->unit_cost); ?></td>
    <td><?php echo e(number_format($subTotal, 2)); ?></td>
</tr>
