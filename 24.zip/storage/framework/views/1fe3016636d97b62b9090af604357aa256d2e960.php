<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-6 offset-md-3">
                    <div class="card card-block sameheight-item">
                        <div class="title-block">
                            <h3 class="title">Nuevo usuario</h3>
                        </div>
                        <form role="form" method="POST" action="<?php echo e(url('admin/users/new')); ?>" novalidate>
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="control-label">Nombre</label>
                                <input id="name" class="form-control underlined" type="text" placeholder="Nombre" name="name" value="<?php echo e(old('name')); ?>" required>
                                <?php if($errors->has('name')): ?>
                                    <span class="has-error">
                                        <?php echo e($errors->first('name')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email" class="control-label">Correo</label>
                                <input id="email" class="form-control underlined" type="email" placeholder="Correo" name="email" value="<?php echo e(old('email')); ?>" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="has-error">
                                        <?php echo e($errors->first('email')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="role" class="control-label">Rol</label>
                                <select id="role" name="role" class="form-control">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>" <?php echo e($role->id == old('role') ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="control-label">Contraseña</label>
                                <input id="password" class="form-control underlined" type="password" placeholder="Contraseña" name="password" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="has-error">
                                        <?php echo e($errors->first('password')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('password-confirm') ? ' has-error' : ''); ?>">
                                <label for="password-confirm" class="control-label">Confirmar contraseña</label>
                                <input id="password-confirm" class="form-control underlined" type="password" placeholder="Confirmar contraseña" name="password_confirmation" required>
                                <?php if($errors->has('password-confirm')): ?>
                                    <span class="has-error">
                                        <?php echo e($errors->first('password-confirm')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(url('admin/users')); ?>" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>