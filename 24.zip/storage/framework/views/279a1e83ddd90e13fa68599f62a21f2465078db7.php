<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-10 offset-md-1">
                    <div class="card card-block">
                        <div class="title-block">
                            <h3 class="title">Editar Cuenta por Pagar</h3>
                        </div>
                        <form method="POST" action="<?php echo e(url('product/debts/edit', ['id' => $debt->id])); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('provider') ? ' has-error' : ''); ?>">
                                        <label for="provider" class="control-label">Proveedor</label>
                                        <p><?php echo e($debt->provider->name); ?></p>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('payment_date') ? ' has-error' : ''); ?>">
                                        <label for="payment-date" class="control-label">Fecha de pago</label>
                                        <?php echo e(Form::text('payment_date', $debt->payment_date, ['class' => 'form-control underlined datepicker', 'placeholder' => 'Fecha de pago', 'id' => 'payment-date'])); ?>

                                        <?php if($errors->has('payment_date')): ?>
                                            <span class="has-error">
                                            <?php echo e(ucfirst($errors->first('payment_date'))); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('amount') ? ' has-error' : ''); ?>">
                                        <label for="amount" class="control-label">Monto</label>
                                        <p><?php echo e($debt->amount); ?></p>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                                        <label for="status" class="control-label">Status Cuenta</label>
                                        <?php echo e(Form::select('status', ['Y' => 'Activa', 'N' => 'Inactiva'], $debt->raw_status, ['class' => 'form-control chosen-select', 'id' => 'status'])); ?>

                                        <span id="error-status" class="has-error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(url('product/debts')); ?>" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>