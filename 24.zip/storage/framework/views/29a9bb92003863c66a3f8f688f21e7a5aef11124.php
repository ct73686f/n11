<tr>
    <td><?php echo e($product->id); ?></td>
    <td><?php echo e($product->barcode->code); ?></td>
    <td><?php echo e($product->description); ?></td>
    <td><?php echo e($quantity); ?></td>
    <td><?php echo e($product->cost->unit_price); ?></td>
    <td><?php echo e($product->cost->wholesale_price); ?></td>
    <td><?php echo e(number_format($subTotal, 2)); ?></td>
    <td><a href="#" class="btn btn-secondary btn-sm product-remove"><i class="fa fa-remove"></i></a></td>
</tr>
