<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-6 offset-md-3">
                    <div class="card card-block">
                        <div class="title-block">
                            <h3 class="title">Nuevo documento efectivo</h3>
                        </div>
                        <form role="form" method="POST" action="<?php echo e(url('product/documents-cash/new')); ?>" novalidate>
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                <label for="description" class="control-label">Descripción</label>
                                <?php echo e(Form::text('description', null, ['class' => 'form-control underlined', 'placeholder' => 'Descripción', 'id' => 'description'])); ?>

                                <?php if($errors->has('description')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('description'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('output_type') ? ' has-error' : ''); ?>">
                                <label for="output-type" class="control-label">Tipo de salida</label>
                                <?php echo e(Form::select('output_type', ['E' => 'Entrada Efectivo', 'S' => 'Salida Efectivo'], null, ['id' => 'output-type', 'class' => 'form-control chosen-select'])); ?>

                                <?php if($errors->has('output_type')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('output_type'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <a href="<?php echo e(url('product/documents-cash')); ?>" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>