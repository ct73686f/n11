<?php $__env->startSection('action-buttons'); ?>
    <a href="<?php echo e(url('product/invoice-details/new')); ?>" class="btn btn-sm header-btn">
        <i class="fa fa-list-alt"></i> <span>Agregar detalle factura</span>
    </a>
    <div class="btn-group">
        <button type="button" class="btn btn-sm header-btn"><i class="fa fa-ellipsis-v"></i> <span>Mostrar</span>
        </button>
        <button type="button" class="btn btn-sm header-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">
            <span class="sr-only">Toggle Dropdown</span>
        </button>
        <div class="dropdown-menu">
            <?php $params = []; $params['pages'] = 10; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/invoice-details') . '?' . $params); ?>">10 detalles de factura</a>
            <?php $params = []; $params['pages'] = 20; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/invoice-details') . '?' . $params); ?>">20 detalles factura</a>
            <?php $params = []; $params['pages'] = 30; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/invoice-details') . '?' . $params); ?>">30 detalles factura</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-block">
                            <div class="card-title-block">
                                <h3 class="title">Detalles Factura</h3>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <section class="example">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('invoice_id', 'Factura'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('product_id', 'Producto'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('quantity', 'Cantidad'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('unit_price', 'Precio Unitario'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('unit_cost', 'Costo Unitario'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('sub_total', 'Sub Total'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Creado en'));?></th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $invoiceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoiceDetail): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <tr>
                                                <td><?php echo e($invoiceDetail->id); ?></td>
                                                <td><?php echo e($invoiceDetail->invoice->description); ?></td>
                                                <td><?php echo e($invoiceDetail->product->description); ?></td>
                                                <td><?php echo e($invoiceDetail->quantity); ?></td>
                                                <td><?php echo e($invoiceDetail->unit_price); ?></td>
                                                <td><?php echo e($invoiceDetail->unit_cost); ?></td>
                                                <td><?php echo e($invoiceDetail->sub_total); ?></td>
                                                <td><?php echo e($invoiceDetail->created_at->format('d/m/Y - H:i A')); ?></td>
                                                <td>
                                                    <!--<a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/invoice-details/delete', ['id' => $invoiceDetail->id])); ?>"><i class="fa fa-remove"></i></a>-->
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </tbody>
                                    </table>
                                    <nav class="text-xs-right">
                                        <?php echo $invoiceDetails->appends(Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?>

                                    </nav>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>