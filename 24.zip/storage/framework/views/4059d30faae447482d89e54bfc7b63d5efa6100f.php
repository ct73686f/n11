<?php $__env->startSection('action-buttons'); ?>
    <a href="<?php echo e(url('product/products/new')); ?>" class="btn btn-sm header-btn">
        <i class="fa fa-cart-plus"></i> <span>Agregar producto</span>
    </a>
    <div class="btn-group">
        <button type="button" class="btn btn-sm header-btn"><i class="fa fa-ellipsis-v"></i> <span>Mostrar</span>
        </button>
        <button type="button" class="btn btn-sm header-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">
            <span class="sr-only">Toggle Dropdown</span>
        </button>
        <div class="dropdown-menu">
            <?php $params = []; $params['pages'] = 10; $params = http_build_query(array_merge($params,
                    Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/products') . '?' . $params); ?>">10 productos</a>
            <?php $params = []; $params['pages'] = 20; $params = http_build_query(array_merge($params,
                    Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/products') . '?' . $params); ?>">20 productos</a>
            <?php $params = []; $params['pages'] = 30; $params = http_build_query(array_merge($params,
                    Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/products') . '?' . $params); ?>">30 productos</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-block">
                            <div class="card-title-block">
                                <h3 class="title">Productos</h3>
                                <form id="search-form" action="<?php echo e(url('product/products')); ?>" method="GET">
                                    <div class="form-group">
                                        <?php if(Request::has('pages')): ?>
                                            <input type="hidden" name="pages" value="<?php echo e(Request::get('pages')); ?>">
                                        <?php endif; ?>
                                        <?php echo e(Form::text('search', Request::get('search'), ['class' => 'form-control underlined', 'placeholder' => 'Buscar producto', 'id' => 'search'])); ?>

                                        <?php if(Request::has('sort')): ?>
                                            <input type="hidden" name="sort" value="<?php echo e(Request::get('sort')); ?>">
                                        <?php endif; ?>
                                        <?php if(Request::has('order')): ?>
                                            <input type="hidden" name="order" value="<?php echo e(Request::get('order')); ?>">
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <section class="example">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('description', 'Descripción'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('image', 'Imagen'));?></th>
                                            <th>Precio Unitario</th>
                                            <th>Proveedor(es)</th>
                                            <th>Categoría(s)</th>
                                            <th>Stock</th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Creado en'));?></th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <tr>
                                                <td><?php echo e($product->id); ?></td>
                                                <td><?php echo e($product->description); ?></td>
                                                <td><img class="img-thumbnail img-responsive"
                                                         src="uploads/<?php echo e($product->thumbnail); ?>" alt=""></td>
                                                <td><?php echo e($product->cost->unit_price); ?></td>
                                                <td><?php echo e($product->providers->implode('name', ', ')); ?></td>
                                                <td><?php echo e($product->categories->implode('description', ', ')); ?></td>
                                                <td><?php echo e(is_null($product->inventory) ? 0 : $product->inventory->current); ?></td>
                                                <td><?php echo e($product->created_at->format('d/m/Y - H:i A')); ?></td>
                                                <td>
                                                    <a class="btn btn-sm btn-secondary"
                                                       href="<?php echo e(url('product/products/edit', ['id' => $product->id])); ?>"><i
                                                                class="fa fa-edit"></i></a>
                                                    <a class="btn btn-sm btn-secondary"
                                                       href="<?php echo e(url('product/products/delete', ['id' => $product->id])); ?>"><i
                                                                class="fa fa-remove"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </tbody>
                                    </table>
                                    <nav class="text-xs-right">
                                        <?php echo $products->appends(Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?>

                                    </nav>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
    <script>
        $(function () {
            /*$('#search-form').on('submit', function (e) {
                e.preventDefault();
            });*/
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>