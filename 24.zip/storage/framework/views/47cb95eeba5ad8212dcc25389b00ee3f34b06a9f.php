<?php $__env->startSection('action-buttons'); ?>
    <a href="<?php echo e(url('product/movements/new')); ?>" class="btn btn-sm header-btn">
        <i class="fa fa-cart-plus"></i> <span>Agregar movimiento</span>
    </a>
    <div class="btn-group">
        <button type="button" class="btn btn-sm header-btn"><i class="fa fa-ellipsis-v"></i> <span>Mostrar</span>
        </button>
        <button type="button" class="btn btn-sm header-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">
            <span class="sr-only">Toggle Dropdown</span>
        </button>
        <div class="dropdown-menu">
            <?php $params = []; $params['pages'] = 10; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/movements') . '?' . $params); ?>">10 movimientos</a>
            <?php $params = []; $params['pages'] = 20; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/movements') . '?' . $params); ?>">20 movimientos</a>
            <?php $params = []; $params['pages'] = 30; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/movements') . '?' . $params); ?>">30 movimientos</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-block">
                            <div class="card-title-block">
                                <h3 class="title">Movimientos</h3>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <section class="example">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('document_id', 'Movimiento'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('user_id', 'Usuario'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('total', 'Total'));?></th>
                                            <th>Tipo Salida</th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Creado en'));?></th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <tr>
                                                <td><?php echo e($movement->id); ?></td>
                                                <td><?php echo e($movement->document->description); ?></td>
                                                <td><?php echo e($movement->user->name); ?></td>
                                                <td><?php echo e($movement->total); ?></td>
                                                <td><?php echo e($movement->document->output_type); ?></td>
                                                <td><?php echo e($movement->created_at->format('d/m/Y - H:i A')); ?></td>
                                                <td>
                                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/movements/view', ['id' => $movement->id])); ?>"><i class="fa fa-eye"></i></a>
                                                    <a class="btn btn-sm btn-secondary" target="_blank" href="<?php echo e(url('product/movements/pdf', ['id' => $movement->id])); ?>"><i class="fa fa-file-pdf-o"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </tbody>
                                    </table>
                                    <nav class="text-xs-right">
                                        <?php echo $movements->appends(Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?>

                                    </nav>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>