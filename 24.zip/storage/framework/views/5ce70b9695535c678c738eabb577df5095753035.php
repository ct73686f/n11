<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-6 offset-md-3">
                    <div class="card card-block">
                        <div class="title-block">
                            <h3 class="title">Nuevo producto</h3>
                        </div>
                        <form role="form" enctype="multipart/form-data" method="POST" action="<?php echo e(url('product/products/new')); ?>" novalidate>
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                <label for="description" class="control-label">Descripción</label>
                                <?php echo e(Form::text('description', null, ['class' => 'form-control underlined', 'placeholder' => 'Descripción', 'id' => 'description'])); ?>

                                <?php if($errors->has('description')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('description'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                                <label for="image" class="control-label">Imagen</label>
                                <?php echo e(Form::file('image', ['class' => 'form-control underlined', 'id' => 'image'])); ?>

                                <?php if($errors->has('image')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('image'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('provider') ? ' has-error' : ''); ?>">
                                <label for="provider" class="control-label">Proveedor(es)</label>
                                <?php echo e(Form::select('provider[]', $providers, null, ['multiple' => true, 'id' => 'provider', 'class' => 'form-control chosen-select', 'data-placeholder' => 'Seleccione a los proveedores'])); ?>

                                <?php if($errors->has('provider')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('provider'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                                <label for="category" class="control-label">Categoría(s)</label>
                                <?php echo e(Form::select('category[]', $categories, null, ['multiple' => true, 'id' => 'category', 'class' => 'form-control chosen-select', 'data-placeholder' => 'Seleccione las categorias'])); ?>

                                <?php if($errors->has('category')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('category'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('bar_code') ? ' has-error' : ''); ?>">
                                <label for="bar-code" class="control-label">Código(s) de Barra</label>
                                <?php echo e(Form::text('bar_code', null, ['class' => 'form-control underlined multi-values', 'placeholder' => 'Código Barra', 'id' => 'bar-code', 'data-default' => 'Agregar código de barra'])); ?>

                                <?php if($errors->has('bar_code')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('bar_code'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('unit_price') ? ' has-error' : ''); ?>">
                                <label for="unit-price" class="control-label">Precio unitario</label>
                                <?php echo e(Form::text('unit_price', null, ['class' => 'form-control underlined', 'placeholder' => 'Precio unitario', 'id' => 'unit-price'])); ?>

                                <?php if($errors->has('unit_price')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('unit_price'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('unit_cost') ? ' has-error' : ''); ?>">
                                <label for="unit-cost" class="control-label">Costo unitario</label>
                                <?php echo e(Form::text('unit_cost', null, ['class' => 'form-control underlined', 'placeholder' => 'Costo unitario', 'id' => 'unit-cost'])); ?>

                                <?php if($errors->has('unit_cost')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('unit_cost'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('wholesale_price') ? ' has-error' : ''); ?>">
                                <label for="wholesale-price" class="control-label">Precio por mayor</label>
                                <?php echo e(Form::text('wholesale_price', null, ['class' => 'form-control underlined', 'placeholder' => 'Precio por mayor', 'id' => 'wholesale-price'])); ?>

                                <?php if($errors->has('wholesale_price')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('wholesale_price'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('quantity') ? ' has-error' : ''); ?>">
                                <label for="quantity" class="control-label">Cantidad</label>
                                <?php echo e(Form::text('quantity', null, ['class' => 'form-control underlined', 'placeholder' => 'Cantidad', 'id' => 'quantity'])); ?>

                                <?php if($errors->has('quantity')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('quantity'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <a href="<?php echo e(url('product/products')); ?>" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>