<?php $__env->startSection('action-buttons'); ?>
    <a href="<?php echo e(url('product/categories/new')); ?>" class="btn btn-sm header-btn">
        <i class="fa fa-tag"></i> <span>Agregar categoría</span>
    </a>
    <div class="btn-group">
        <button type="button" class="btn btn-sm header-btn"><i class="fa fa-ellipsis-v"></i> <span>Mostrar</span>
        </button>
        <button type="button" class="btn btn-sm header-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">
            <span class="sr-only">Toggle Dropdown</span>
        </button>
        <div class="dropdown-menu">
            <?php $params = []; $params['pages'] = 10; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/categories') . '?' . $params); ?>">10 categorias</a>
            <?php $params = []; $params['pages'] = 20; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/categories') . '?' . $params); ?>">20 categorias</a>
            <?php $params = []; $params['pages'] = 30; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/categories') . '?' . $params); ?>">30 categorias</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-block">
                            <div class="card-title-block">
                                <h3 class="title">Categorias</h3>
                                <form id="search-form" action="<?php echo e(url('product/categories')); ?>" method="GET">
                                    <div class="form-group">
                                        <?php if(Request::has('pages')): ?>
                                            <input type="hidden" name="pages" value="<?php echo e(Request::get('pages')); ?>">
                                        <?php endif; ?>
                                        <?php echo e(Form::text('search', Request::get('search'), ['class' => 'form-control underlined', 'placeholder' => 'Buscar categoría', 'id' => 'search'])); ?>

                                        <?php if(Request::has('sort')): ?>
                                            <input type="hidden" name="sort" value="<?php echo e(Request::get('sort')); ?>">
                                        <?php endif; ?>
                                        <?php if(Request::has('order')): ?>
                                            <input type="hidden" name="order" value="<?php echo e(Request::get('order')); ?>">
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <section class="example">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('description', 'Descripción'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Creado en'));?></th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <tr>
                                                <td><?php echo e($category->id); ?></td>
                                                <td><?php echo e($category->description); ?></td>
                                                <td><?php echo e($category->created_at->format('d/m/Y - H:i A')); ?></td>
                                                <td>
                                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/categories/edit', ['id' => $category->id])); ?>"><i class="fa fa-edit"></i></a>
                                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/categories/delete', ['id' => $category->id])); ?>"><i class="fa fa-remove"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </tbody>
                                    </table>
                                    <nav class="text-xs-right">
                                        <?php echo $categories->appends(Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?>

                                    </nav>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>