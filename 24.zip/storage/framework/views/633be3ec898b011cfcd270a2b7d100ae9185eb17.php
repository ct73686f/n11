<?php $__env->startSection('content'); ?>

    <div class="auth">
        <div class="auth-container">
            <div class="card">
                <header class="auth-header">
                    <h1 class="auth-title">
                        <img class="logo" src="img/logo.png" title="BH Developers" alt="BHD Logo">
                    </h1>
                </header>
                <div class="auth-content">
                    <p class="text-xs-center">INICIAR SESION</p>
                    <form id="login-form" method="POST" action="<?php echo e(url('/login')); ?>" novalidate="">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email">Correo</label>
                            <input type="email" class="form-control underlined"
                                   name="email" id="email" placeholder="Correo" value="<?php echo e(old('email')); ?>" required>
                            <?php if($errors->has('email')): ?>
                                <span class="has-error">
                                    <?php echo e($errors->first('email')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password">Contraseña</label>
                            <input type="password" class="form-control underlined"
                                   name="password" id="password" placeholder="Contraseña" required>
                            <?php if($errors->has('password')): ?>
                                <span class="has-error">
                                    <?php echo e($errors->first('password')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="remember">
                                <input class="checkbox" checked="checked" name="remember" id="remember" type="checkbox">
                                <span>Recordarme</span>
                            </label>
                            <a href="<?php echo e(url('/password/reset')); ?>" class="forgot-btn pull-right">¿Olvidaste tu contraseña?</a></div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-primary">Iniciar sesión</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>