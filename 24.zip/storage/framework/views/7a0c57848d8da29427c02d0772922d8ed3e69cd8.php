<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-10 offset-md-1">
                    <div class="card card-block">
                        <div class="title-block">
                            <h3 class="title">Movimiento Inventario # <?php echo e($movement->id); ?></h3>
                        </div>
                       <div class="row">
                           <div class="col-md-4">
                               <div class="form-group<?php echo e($errors->has('document') ? ' has-error' : ''); ?>">
                                   <label for="document" class="control-label">Tipo de movimiento</label>
                                   <p>
                                       <?php echo e($movement->document->description . ' - ' . $movement->document->output_type); ?>

                                   </p>
                               </div>
                           </div>
                           <?php if($movement->document->raw_output_type == 'E'): ?>
                               <div class="col-md-8">
                                   <label>No. Factura</label>
                                   <p>
                                       <?php echo e($movement->invoice_number); ?>

                                   </p>
                               </div>
                           <?php endif; ?>
                           <div class="col-md-8">
                               <label>Total</label>
                               <p>
                                   <?php echo e($movement->total); ?>

                               </p>
                           </div>
                       </div>
                    </div>

                    <div class="card card-block">
                        <div class="title-block">
                            <h3 class="title">Detalle Movimiento</h3>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">Productos</h3>
                                        </div>
                                        <section class="example form-group">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover">
                                                    <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Código</th>
                                                        <th>Descripción</th>
                                                        <th>Cantidad</th>
                                                        <th>Precio</th>
                                                        <th>Sub Total</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="movement-products">
                                                    <?php $__currentLoopData = $movement->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($detail->id); ?></td>
                                                            <td><?php echo e($detail->product->id); ?></td>
                                                            <td><?php echo e($detail->product->description); ?></td>
                                                            <td><?php echo e($detail->quantity); ?></td>
                                                            <td><?php echo e($detail->price); ?></td>
                                                            <td><?php echo e($detail->sub_total); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <span id="error-product" class="has-error"></span>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="product-ids">

                        </div>
                        <input type="hidden" id="document-id" name="document">


                        <div class="form-group">
                            <a href="<?php echo e(url('product/movements')); ?>" class="btn btn-secondary">Regresar a movimientos</a>
                            <a href="<?php echo e(url('product/movements/pdf', ['id' => $movement->id])); ?>" class="btn btn-primary">Imprimir PDF</a>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>