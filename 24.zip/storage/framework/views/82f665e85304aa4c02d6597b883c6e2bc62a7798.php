<!-- Main Content -->
<?php $__env->startSection('content'); ?>
    <div class="auth">
        <div class="auth-container">
            <div class="card">
                <header class="auth-header">
                    <h1 class="auth-title">
                        <img class="logo" src="img/logo.png" title="BH Developers" alt="BHD Logo">
                    </h1>
                </header>
                <div class="auth-content">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <p class="text-xs-center">REINICIAR CONTRASEÑA</p>
                    <p class="text-muted text-xs-center">
                        <small>Ingrese su dirección de correo para reiniciar su contraseña.</small>
                    </p>
                    <form id="reset-form" method="POST" action="<?php echo e(url('/password/email')); ?>" novalidate="">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email">Correo</label>
                            <input type="email" class="form-control underlined"
                                   name="email" id="email" placeholder="Correo" value="<?php echo e(old('email')); ?>" required>
                            <?php if($errors->has('email')): ?>
                                <span class="has-error">
                                    <?php echo e($errors->first('email')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-primary">Reiniciar contraseña</button>
                        </div>
                        <div class="form-group clearfix"><a class="pull-left" href="<?php echo e(url('/login')); ?>">Iniciar sesión</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>