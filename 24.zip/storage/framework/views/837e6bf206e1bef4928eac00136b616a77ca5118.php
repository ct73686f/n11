<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-6 offset-md-3">
                    <div class="card card-block sameheight-item">
                        <div class="title-block">
                            <h3 class="title">Editar costo</h3>
                        </div>
                        <form role="form" method="POST" action="<?php echo e(url('product/costs/edit', ['id' => $cost->id])); ?>" novalidate>
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('product') ? ' has-error' : ''); ?>">
                                <label for="product" class="control-label">Producto</label>
                                <?php echo e(Form::select('product', $products, $cost->product->id, ['id' => 'product', 'class' => 'form-control chosen-select'])); ?>

                                <?php if($errors->has('product')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('product'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('unit_price') ? ' has-error' : ''); ?>">
                                <label for="unit-price" class="control-label">Precio unitario</label>
                                <?php echo e(Form::text('unit_price', $cost->unit_price, ['class' => 'form-control underlined', 'placeholder' => 'Precio unitario', 'id' => 'unit-price'])); ?>

                                <?php if($errors->has('unit_price')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('unit_price'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('unit_cost') ? ' has-error' : ''); ?>">
                                <label for="unit-cost" class="control-label">Costo unitario</label>
                                <?php echo e(Form::text('unit_cost', $cost->unit_cost, ['class' => 'form-control underlined', 'placeholder' => 'Costo unitario', 'id' => 'unit-cost'])); ?>

                                <?php if($errors->has('unit_cost')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('unit_cost'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('wholesale_price') ? ' has-error' : ''); ?>">
                                <label for="wholesale-price" class="control-label">Precio por mayor</label>
                                <?php echo e(Form::text('wholesale_price', $cost->wholesale_price, ['class' => 'form-control underlined', 'placeholder' => 'Precio por mayor', 'id' => 'wholesale-price'])); ?>

                                <?php if($errors->has('wholesale_price')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('wholesale_price'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(url('product/costs')); ?>" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>