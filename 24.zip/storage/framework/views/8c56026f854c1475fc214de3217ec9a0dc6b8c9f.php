<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-6 offset-md-3">
                    <div class="card card-block sameheight-item">
                        <div class="title-block">
                            <h3 class="title">Editar tipo de credito</h3>
                        </div>
                        <form role="form" enctype="multipart/form-data" method="POST" action="<?php echo e(url('product/credit-types/edit', ['id' => $creditType->id])); ?>" novalidate>
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                <label for="description" class="control-label">Descripción</label>
                                <?php echo e(Form::text('description', $creditType->description, ['class' => 'form-control underlined', 'placeholder' => 'Descripción', 'id' => 'description'])); ?>

                                <?php if($errors->has('description')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('description'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('term') ? ' has-error' : ''); ?>">
                                <label for="term" class="control-label">Plazos</label>
                                <?php echo e(Form::text('term', $creditType->term, ['class' => 'form-control underlined', 'placeholder' => 'Plazos', 'id' => 'term'])); ?>

                                <?php if($errors->has('term')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('term'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('amount') ? ' has-error' : ''); ?>">
                                <label for="amount" class="control-label">Cantidad</label>
                                <?php echo e(Form::text('amount', $creditType->amount, ['class' => 'form-control underlined', 'placeholder' => 'Cantidad', 'id' => 'amount'])); ?>

                                <?php if($errors->has('amount')): ?>
                                    <span class="has-error">
                                        <?php echo e(ucfirst($errors->first('amount'))); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="form-group">
                                <a href="<?php echo e(url('product/clients')); ?>" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>