<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-6 offset-md-3">
                    <div class="card card-block sameheight-item">
                        <div class="title-block">
                            <h3 class="title">Editar categoría</h3>
                        </div>
                        <form role="form" method="POST" action="<?php echo e(url('product/categories/edit', ['id' => $category->id])); ?>" novalidate>
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                <label for="name" class="control-label">Descripción</label>
                                <input id="name" class="form-control underlined" type="text" placeholder="Descripción" name="description" value="<?php echo e(is_null(old('description')) ? $category->description : old('description')); ?>" required>
                                <?php if($errors->has('description')): ?>
                                    <span class="has-error">
                                        <?php echo e($errors->first('description')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(url('admin/users')); ?>" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>