<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-6 offset-md-3">
                    <div class="card card-block sameheight-item">
                        <section class="section">
                            <form role="form" method="POST" action="<?php echo e(url('product/documents/delete', ['id' => $document->id])); ?>" novalidate>
                                <?php echo e(csrf_field()); ?>

                                <h6>¿Confirma que desea eliminar el documento <?php echo e($document->description); ?>?</h6>
                                <br>
                                <div class="form-group">
                                    <a href="<?php echo e(url('product/documents')); ?>" class="btn btn-secondary">Cancelar</a>
                                    <button type="submit" class="btn btn-primary">Aceptar</button>
                                </div>
                            </form>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>