<?php $__env->startSection('action-buttons'); ?>
    <a href="<?php echo e(url('product/invoices/new')); ?>" class="btn btn-sm header-btn">
        <i class="fa fa-list-alt"></i> <span>Agregar venta de mercaderia</span>
    </a>
    <div class="btn-group">
        <button type="button" class="btn btn-sm header-btn"><i class="fa fa-ellipsis-v"></i> <span>Mostrar</span>
        </button>
        <button type="button" class="btn btn-sm header-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">
            <span class="sr-only">Toggle Dropdown</span>
        </button>
        <div class="dropdown-menu">
            <?php $params = []; $params['pages'] = 10; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/invoices') . '?' . $params); ?>">10 ventas de mercaderia</a>
            <?php $params = []; $params['pages'] = 20; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/invoices') . '?' . $params); ?>">20 ventas de mercaderia</a>
            <?php $params = []; $params['pages'] = 30; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/invoices') . '?' . $params); ?>">30 ventas de mercaderia</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-block">
                            <div class="card-title-block">
                                <h3 class="title">Ventas de mercaderia</h3>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <section class="example">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('description', 'Descripción'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('user_id', 'Usuario'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('client_id', 'Cliente'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('nit', 'NIT'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('discount', 'Descuento'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('total', 'Total'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Creado en'));?></th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <tr>
                                                <td><?php echo e($invoice->id); ?></td>
                                                <td><?php echo e($invoice->description); ?></td>
                                                <td><?php echo e($invoice->user->name); ?></td>
                                                <td><?php echo e($invoice->client->full_name); ?></td>
                                                <td><?php echo e($invoice->nit); ?></td>
                                                <td><?php echo e(number_format($invoice->discount, 2)); ?></td>
                                                <td><?php echo e(number_format($invoice->total, 2)); ?></td>
                                                <td><?php echo e($invoice->created_at->format('d/m/Y - H:i A')); ?></td>
                                                <td>
                                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/invoices/view', ['id' => $invoice->id])); ?>"><i class="fa fa-eye"></i></a>
                                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/invoices/pdf', ['id' => $invoice->id])); ?>" target="_blank"><i class="fa fa-file-pdf-o"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </tbody>
                                    </table>
                                    <nav class="text-xs-right">
                                        <?php echo $invoices->appends(Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?>

                                    </nav>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>