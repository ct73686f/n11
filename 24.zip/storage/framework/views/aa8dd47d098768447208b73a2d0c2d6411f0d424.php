<?php $__env->startSection('action-buttons'); ?>
    <a href="<?php echo e(url('product/credit-types/new')); ?>" class="btn btn-sm header-btn">
        <i class="fa fa-cart-plus"></i> <span>Agregar tipo de credito</span>
    </a>
    <div class="btn-group">
        <button type="button" class="btn btn-sm header-btn"><i class="fa fa-ellipsis-v"></i> <span>Mostrar</span>
        </button>
        <button type="button" class="btn btn-sm header-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">
            <span class="sr-only">Toggle Dropdown</span>
        </button>
        <div class="dropdown-menu">
            <?php $params = []; $params['pages'] = 10; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/credit-types') . '?' . $params); ?>">10 tipos de credito</a>
            <?php $params = []; $params['pages'] = 20; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/credit-types') . '?' . $params); ?>">20 tipos de credito</a>
            <?php $params = []; $params['pages'] = 30; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/credit-types') . '?' . $params); ?>">30 tipos de credito</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-block">
                            <div class="card-title-block">
                                <h3 class="title">Tipos de credito</h3>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <section class="example">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('description', 'Descripción'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('term', 'Plazos'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('amount', 'Cantidad'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Creado en'));?></th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $creditTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creditType): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <tr>
                                                <td><?php echo e($creditType->id); ?></td>
                                                <td><?php echo e($creditType->description); ?></td>
                                                <td><?php echo e($creditType->term); ?></td>
                                                <td><?php echo e($creditType->amount); ?></td>
                                                <td><?php echo e($creditType->created_at->format('d/m/Y - H:i A')); ?></td>
                                                <td>
                                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/credit-types/edit', ['id' => $creditType->id])); ?>"><i class="fa fa-edit"></i></a>
                                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/credit-types/delete', ['id' => $creditType->id])); ?>"><i class="fa fa-remove"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </tbody>
                                    </table>
                                    <nav class="text-xs-right">
                                        <?php echo $creditTypes->appends(Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?>

                                    </nav>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>