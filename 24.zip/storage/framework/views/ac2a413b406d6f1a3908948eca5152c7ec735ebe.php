<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row sameheight-container">
                <div class="col-md-6 offset-md-3">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card card-block sameheight-item">
                        <section class="section">
                            <form role="form" method="POST" action="<?php echo e(url('product/providers/delete', ['id' => $provider->id])); ?>" novalidate>
                                <?php echo e(csrf_field()); ?>

                                <h6>¿Confirma que desea eliminar al proveedor <?php echo e($provider->name); ?>?</h6>
                                <br>
                                <div class="form-group">
                                    <a href="<?php echo e(url('product/providers')); ?>" class="btn btn-secondary">Cancelar</a>
                                    <button type="submit" class="btn btn-primary">Aceptar</button>
                                </div>
                            </form>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>