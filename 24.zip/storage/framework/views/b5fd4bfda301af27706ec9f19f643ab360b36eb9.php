<?php $__env->startSection('action-buttons'); ?>
    <a href="<?php echo e(url('product/accounts-receivables/new')); ?>" class="btn btn-sm header-btn">
        <i class="fa fa-money"></i> <span>Agregar cuenta por cobrar</span>
    </a>
    <div class="btn-group">
        <button type="button" class="btn btn-sm header-btn"><i class="fa fa-ellipsis-v"></i> <span>Mostrar</span>
        </button>
        <button type="button" class="btn btn-sm header-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                aria-expanded="false">
            <span class="sr-only">Toggle Dropdown</span>
        </button>
        <div class="dropdown-menu">
            <?php $params = []; $params['pages'] = 10; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/accounts-receivables') . '?' . $params); ?>">10 cuentas por cobrar</a>
            <?php $params = []; $params['pages'] = 20; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/accounts-receivables') . '?' . $params); ?>">20 cuentas por cobrar</a>
            <?php $params = []; $params['pages'] = 30; $params = http_build_query(array_merge($params, Request::except('pages'))); ?>
            <a class="dropdown-item" href="<?php echo e(url('product/accounts-receivables') . '?' . $params); ?>">30 cuentas por cobrar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="content responsive-tables-page">
        <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-block">
                            <div class="card-title-block">
                                <h3 class="title">Cuentas por Cobrar</h3>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <section class="example">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('invoice_id', 'Venta de mercaderia'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('client_id', 'Cliente'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('payment_date', 'Fecha de pago'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('total', 'Total'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('status', 'Pagado'));?></th>
                                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Creado en'));?></th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $accountsReceivables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receivable): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <tr>
                                                <td><?php echo e($receivable->id); ?></td>
                                                <td><?php echo e($receivable->invoice->description); ?></td>
                                                <td><?php echo e($receivable->client->full_name); ?></td>
                                                <td><?php echo e($receivable->payment_date); ?></td>
                                                <td><?php echo e($receivable->total); ?></td>
                                                <td><?php echo e($receivable->status); ?></td>
                                                <td><?php echo e($receivable->created_at->format('d/m/Y - H:i A')); ?></td>
                                                <td>
                                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/accounts-receivables/edit', ['id' => $receivable->id])); ?>"><i class="fa fa-edit"></i></a>
                                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(url('product/accounts-receivables/delete', ['id' => $receivable->id])); ?>"><i class="fa fa-remove"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </tbody>
                                    </table>
                                    <nav class="text-xs-right">
                                        <?php echo $accountsReceivables->appends(Request::except('page'))->render('vendor.pagination.bootstrap-4'); ?>

                                    </nav>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>